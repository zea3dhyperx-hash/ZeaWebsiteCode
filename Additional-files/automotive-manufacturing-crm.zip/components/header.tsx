import Link from "next/link"
import { Button } from "@/components/ui/button"

export function Header() {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center gap-8">
            <Link href="/" className="flex items-center space-x-2">
              <span className="text-xl font-bold text-primary">ZeaCRM</span>
            </Link>
            <nav className="hidden md:flex items-center gap-6">
              <Link
                href="/automotive"
                className="text-sm font-medium text-foreground hover:text-primary transition-colors"
              >
                Automotive
              </Link>
              <Link
                href="/playbooks/videos"
                className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors"
              >
                Demo Videos
              </Link>
              <Link
                href="/features"
                className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors"
              >
                Features
              </Link>
            </nav>
          </div>
          <div className="flex items-center gap-4">
            <Button asChild variant="ghost" size="sm">
              <Link href="/login">Sign In</Link>
            </Button>
            <Button asChild size="sm">
              <Link href="/get-started">Get Started</Link>
            </Button>
          </div>
        </div>
      </div>
    </header>
  )
}
