"use client"

import { useEffect, useRef } from "react"

export default function AniAuto() {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas size
    const updateSize = () => {
      const parent = canvas.parentElement
      if (!parent) return
      canvas.width = parent.clientWidth
      canvas.height = parent.clientHeight
    }
    updateSize()
    window.addEventListener("resize", updateSize)

    // Animation variables
    let frame = 0
    const particles: Array<{
      x: number
      y: number
      vx: number
      vy: number
      size: number
      color: string
    }> = []

    // Create particles
    for (let i = 0; i < 50; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 2,
        vy: (Math.random() - 0.5) * 2,
        size: Math.random() * 3 + 1,
        color: `hsl(${Math.random() * 360}, 70%, 60%)`,
      })
    }

    // Animation loop
    const animate = () => {
      frame++
      ctx.fillStyle = "rgba(0, 0, 0, 0.05)"
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      // Draw and update particles
      particles.forEach((p) => {
        ctx.beginPath()
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2)
        ctx.fillStyle = p.color
        ctx.fill()

        // Update position
        p.x += p.vx
        p.y += p.vy

        // Bounce off edges
        if (p.x < 0 || p.x > canvas.width) p.vx *= -1
        if (p.y < 0 || p.y > canvas.height) p.vy *= -1
      })

      // Draw connections
      particles.forEach((p1, i) => {
        particles.slice(i + 1).forEach((p2) => {
          const dx = p1.x - p2.x
          const dy = p1.y - p2.y
          const dist = Math.sqrt(dx * dx + dy * dy)

          if (dist < 100) {
            ctx.beginPath()
            ctx.moveTo(p1.x, p1.y)
            ctx.lineTo(p2.x, p2.y)
            ctx.strokeStyle = `rgba(255, 255, 255, ${1 - dist / 100})`
            ctx.lineWidth = 0.5
            ctx.stroke()
          }
        })
      })

      // Draw car icon in center
      const centerX = canvas.width / 2
      const centerY = canvas.height / 2
      const scale = 1 + Math.sin(frame * 0.02) * 0.1

      ctx.save()
      ctx.translate(centerX, centerY)
      ctx.scale(scale, scale)

      // Simple car shape
      ctx.fillStyle = "rgba(255, 255, 255, 0.9)"
      ctx.fillRect(-40, -15, 80, 30)
      ctx.fillRect(-30, -30, 20, 15)
      ctx.fillRect(10, -30, 20, 15)

      // Wheels
      ctx.beginPath()
      ctx.arc(-25, 15, 8, 0, Math.PI * 2)
      ctx.arc(25, 15, 8, 0, Math.PI * 2)
      ctx.fillStyle = "rgba(100, 100, 100, 0.9)"
      ctx.fill()

      ctx.restore()

      requestAnimationFrame(animate)
    }

    animate()

    return () => {
      window.removeEventListener("resize", updateSize)
    }
  }, [])

  return (
    <div className="rounded-xl border border-border overflow-hidden bg-slate-900 aspect-video">
      <canvas ref={canvasRef} className="w-full h-full" />
    </div>
  )
}
