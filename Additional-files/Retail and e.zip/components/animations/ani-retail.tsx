"use client"

export default function AniRetail() {
  return (
    <div className="relative w-full aspect-square rounded-xl border border-border bg-gradient-to-br from-primary/5 via-accent/5 to-secondary/5 overflow-hidden p-8 flex items-center justify-center">
      {/* Animated circles */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="absolute w-32 h-32 rounded-full bg-primary/20 animate-ping" />
        <div
          className="absolute w-48 h-48 rounded-full bg-accent/20 animate-pulse"
          style={{ animationDelay: "0.5s" }}
        />
        <div
          className="absolute w-64 h-64 rounded-full bg-secondary/20 animate-ping"
          style={{ animationDelay: "1s" }}
        />
      </div>

      {/* Center content */}
      <div className="relative z-10 text-center space-y-4">
        <div className="w-24 h-24 mx-auto rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center animate-bounce">
          <svg className="w-12 h-12 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
          </svg>
        </div>
        <p className="text-sm font-semibold text-muted-foreground">AI-Powered Automation</p>
      </div>

      {/* Floating icons */}
      <div className="absolute top-8 left-8 w-12 h-12 rounded-lg bg-card border border-border flex items-center justify-center animate-pulse">
        <span className="text-2xl">🛒</span>
      </div>
      <div
        className="absolute top-8 right-8 w-12 h-12 rounded-lg bg-card border border-border flex items-center justify-center animate-pulse"
        style={{ animationDelay: "0.3s" }}
      >
        <span className="text-2xl">💬</span>
      </div>
      <div
        className="absolute bottom-8 left-8 w-12 h-12 rounded-lg bg-card border border-border flex items-center justify-center animate-pulse"
        style={{ animationDelay: "0.6s" }}
      >
        <span className="text-2xl">📊</span>
      </div>
      <div
        className="absolute bottom-8 right-8 w-12 h-12 rounded-lg bg-card border border-border flex items-center justify-center animate-pulse"
        style={{ animationDelay: "0.9s" }}
      >
        <span className="text-2xl">🎯</span>
      </div>
    </div>
  )
}
