import Link from "next/link"
import { Button } from "@/components/ui/button"

export function Header() {
  return (
    <header className="border-b border-border bg-background sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <Link href="/" className="text-xl font-bold text-primary">
          ZeaCRM
        </Link>
        <nav className="hidden md:flex items-center gap-6">
          <Link
            href="/solutions"
            className="text-sm font-medium text-muted-foreground hover:text-foreground transition"
          >
            Solutions
          </Link>
          <Link href="/features" className="text-sm font-medium text-muted-foreground hover:text-foreground transition">
            Features
          </Link>
          <Link href="/pricing" className="text-sm font-medium text-muted-foreground hover:text-foreground transition">
            Pricing
          </Link>
          <Link
            href="/resources"
            className="text-sm font-medium text-muted-foreground hover:text-foreground transition"
          >
            Resources
          </Link>
        </nav>
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="sm" asChild>
            <Link href="/login">Login</Link>
          </Button>
          <Button size="sm" asChild>
            <Link href="/get-started">Get Started</Link>
          </Button>
        </div>
      </div>
    </header>
  )
}
