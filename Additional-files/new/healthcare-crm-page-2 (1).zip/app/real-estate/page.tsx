"use client"
import { useEffect, useRef, useState } from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import ChatWidget from "@/components/chatbot"
import FAQ from "@/components/faq"
import Link from "next/link"
import AniRealEstate from "@/components/animations/ani-realestate"
import { AnimatedCheckmark } from "@/components/animated-checkmark"

export default function RealEstateCRM() {
  const [expanded, setExpanded] = useState(false)
  const [lockedOpen, setLockedOpen] = useState(false)
  const [videoSrc, setVideoSrc] = useState("")
  const iframeRef = useRef<HTMLIFrameElement>(null)
  const panelRef = useRef<HTMLDivElement>(null)
  const [panelHeight, setPanelHeight] = useState(0)
  const hoverTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const [selectedRole, setSelectedRole] = useState<"builders" | "property" | "brokers" | "consultants">("builders")

  useEffect(() => {
    if (panelRef.current) setPanelHeight(panelRef.current.scrollHeight)
  }, [expanded])

  useEffect(() => {
    return () => {
      if (hoverTimeoutRef.current) {
        clearTimeout(hoverTimeoutRef.current)
      }
    }
  }, [])

  useEffect(() => {
    setVideoSrc("https://www.youtube.com/embed/OTr-FSnv_vA?enablejsapi=1&rel=0&modestbranding=1&playsinline=1")
  }, [])

  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (!event.origin.includes("youtube.com")) return
      let data: any = event.data
      try {
        if (typeof data === "string") data = JSON.parse(data)
      } catch {
        return
      }
      if (!data?.event) return
      const state = data.info?.playerState !== undefined ? data.info.playerState : data.data
      if (state === 1) {
        setLockedOpen(true)
        setExpanded(true)
      } else if (state === 0 || state === 2) {
        setLockedOpen(false)
      }
    }
    window.addEventListener("message", handleMessage)
    return () => window.removeEventListener("message", handleMessage)
  }, [])

  const onIframeLoad = () => {
    const win = iframeRef.current?.contentWindow
    if (!win) return
    try {
      win.postMessage(JSON.stringify({ event: "listening" }), "*")
      win.postMessage(JSON.stringify({ event: "command", func: "addEventListener", args: ["onStateChange"] }), "*")
    } catch {}
  }

  useEffect(() => {
    if (!expanded && iframeRef.current && videoSrc) {
      iframeRef.current.contentWindow?.postMessage(
        JSON.stringify({ event: "command", func: "stopVideo", args: [] }),
        "*",
      )
      iframeRef.current.src = videoSrc
    }
  }, [expanded, videoSrc])

  const workflowData = {
    builders: [
      { icon: "cloud", title: "Capture leads automatically from listings and ads", badge: "Leads sent" },
      { icon: "refresh", title: "Project updates via WhatsApp", badge: "Updates" },
      { icon: "document", title: "Generate and sign digital booking forms", badge: "Booking forms" },
      { icon: "dollar", title: "Track payment milestones and due dates", badge: "Track Payment" },
    ],
    property: [
      { icon: "cloud", title: "Onboard tenants with automated agreements", badge: "Applications" },
      { icon: "refresh", title: "Track maintenance requests in real-time", badge: "Requests" },
      { icon: "document", title: "Send lease renewal reminders automatically", badge: "Renewals" },
      { icon: "dollar", title: "Monitor rent collection and payments", badge: "Rent Track" },
    ],
    brokers: [
      { icon: "cloud", title: "Import leads from property portals automatically", badge: "Lead Forms" },
      { icon: "refresh", title: "Schedule property tours automatically", badge: "Tours" },
      { icon: "document", title: "Match buyers to properties using AI suggestions", badge: "Offers" },
      { icon: "dollar", title: "Send property details instantly via WhatsApp", badge: "Details Sent" },
    ],
    consultants: [
      { icon: "cloud", title: "Automate follow-ups, calls, and meeting reminders", badge: "Onboarding" },
      { icon: "refresh", title: "Share market analysis reports instantly", badge: "Analysis" },
      { icon: "document", title: "Create and deliver strategy reports", badge: "Reports" },
      { icon: "dollar", title: "Assign tasks and track every client conversation", badge: "Track" },
    ],
  }

  const getIcon = (iconType: string) => {
    switch (iconType) {
      case "cloud":
        return (
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
          />
        )
      case "refresh":
        return (
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
          />
        )
      case "document":
        return (
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
          />
        )
      case "dollar":
        return (
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
          />
        )
      default:
        return null
    }
  }

  return (
    <>
      <Header />

      {/* Top Video Reveal */}
      <section
        className="bg-gradient-to-r from-amber-400 via-pink-500 to-indigo-600 text-slate-900"
        onMouseEnter={() => {
          if (hoverTimeoutRef.current) {
            clearTimeout(hoverTimeoutRef.current)
          }
          hoverTimeoutRef.current = setTimeout(() => {
            setExpanded(true)
          }, 0)
        }}
        onMouseLeave={(e) => {
          if (hoverTimeoutRef.current) {
            clearTimeout(hoverTimeoutRef.current)
            hoverTimeoutRef.current = null
          }

          if (lockedOpen) return

          const relatedTarget = e.relatedTarget as HTMLElement | null

          if (
            relatedTarget === null ||
            (iframeRef.current && relatedTarget instanceof Node && iframeRef.current.contains(relatedTarget))
          ) {
            return
          }

          if (relatedTarget && typeof relatedTarget.closest === "function") {
            if (relatedTarget.closest("header")) {
              setExpanded(false)
              return
            }
          }
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <button
            onFocus={() => setExpanded(true)}
            className="w-full py-3 font-semibold tracking-wide flex items-center justify-center gap-2"
            aria-expanded={expanded}
          >
            Watch me
            <span className={`transition-transform ${expanded ? "rotate-180" : "rotate-0"}`}>▼</span>
          </button>
        </div>
        <div
          style={{ maxHeight: expanded ? panelHeight : 0 }}
          className="transition-[max-height] duration-500 ease-out overflow-hidden bg-slate-950 border-t border-black/20"
        >
          <div ref={panelRef} className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div className="relative aspect-video bg-slate-800 rounded-xl overflow-hidden border border-slate-800">
              <button
                aria-label="Close video"
                onClick={() => {
                  setExpanded(false)
                  setLockedOpen(false)
                }}
                className="absolute top-2 right-2 z-10 inline-flex h-9 w-9 items-center justify-center rounded-md bg-black/50 text-white hover:bg-black/70 transition"
              >
                ✕
              </button>
              {videoSrc && (
                <iframe
                  ref={iframeRef}
                  className="w-full h-full"
                  src={videoSrc}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                  title="ZeaCRM Real Estate Video"
                  onLoad={onIframeLoad}
                />
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Hero */}
      <section className="border-b border-border bg-background py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid md:grid-cols-2 gap-10 items-center">
          <div className="text-center md:text-left">
            <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight text-primary">
              Real Estate CRM Powered by AI
            </h1>
            <p className="mt-4 text-muted-foreground text-lg">Smarter Sales, Faster Deals, Happier Clients.</p>
            <p className="mt-3 text-muted-foreground text-lg">
              Manage listings, inquiries, payments, and tenants from one powerful dashboard.
            </p>
            <p className="mt-3 text-muted-foreground text-lg">
              ZeaCRM empowers real estate professionals to automate everything — from lead capture to closing day.
            </p>
            <div className="mt-8 flex gap-4 justify-center md:justify-start">
              <Button asChild size="lg">
                <Link href="/playbooks/videos">Watch Demo Video</Link>
              </Button>
              <Button asChild size="lg" variant="outline">
                <Link href="/get-started">Start Free Trial</Link>
              </Button>
            </div>
          </div>
          <div className="rounded-xl border border-border p-0 object-contain bg-card overflow-hidden">
            <video src="/videos/realvid.mp4" autoPlay muted loop playsInline className="w-full h-auto" />
          </div>
        </div>
      </section>

      {/* Section 1 – The New Era of Real Estate Automation */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24 text-center">
        <div className="md:w-4/5 mx-auto">
          <h2 className="text-4xl md:text-5xl font-extrabold text-[rgba(223,168,34,1)]">
            The New Era of Real Estate Automation
          </h2>
          <p className="mt-4 text-muted-foreground text-lg">
            In real estate, speed and relationships drive every deal.
          </p>
          <p className="mt-3 text-muted-foreground text-lg">
            ZeaCRM helps you work smarter — capturing leads instantly, automating follow-ups, and giving you a complete
            view of every project and client.
          </p>
          <p className="mt-3 text-muted-foreground text-lg">
            ZeaCRM empowers real estate professionals to automate everything — from lead capture to closing day.
          </p>
          <div className="mt-8 grid sm:grid-cols-2 gap-6">
            <div className="p-8 rounded-2xl text-black transition-all duration-300 px-8 py-8 mx-1 my-0 bg-slate-200">
              <div className="flex justify-center mb-4">
                <img src="/images/carbon-sales-ops.png" alt="Sales Operations" className="w-16 h-16" />
              </div>
              <p className="text-lg font-medium text-center">Centralize all your sales, rentals, and project data.</p>
            </div>

            <div className="p-8 rounded-2xl text-black transition-all duration-300 bg-slate-200">
              <div className="flex justify-center mb-4">
                <img
                  src="/images/group-20238.png"
                  alt="Communication Channels"
                  className="tracking-tight my-0 w-20 h-16"
                />
              </div>
              <p className="text-lg font-medium text-center">Automate communication across WhatsApp, email, and SMS.</p>
            </div>

            <div className="p-8 rounded-2xl bg-slate-200 text-black transition-all duration-300">
              <div className="flex justify-center mb-4">
                <img src="/images/group-239.png" alt="AI Predictions" className="w-16 h-16" />
              </div>
              <p className="text-lg font-medium text-center">Predict conversions using AI-powered insights.</p>
            </div>

            <div className="p-8 rounded-2xl bg-slate-200 text-black transition-all duration-300">
              <div className="flex justify-center mb-4">
                <img src="/images/mdi-account-tick.png" alt="Save Time" className="w-16 h-16" />
              </div>
              <p className="text-lg font-medium text-center">Save hours of manual work every week.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Section 2 – Tailored Solutions for Every Role */}
      <section className="bg-black border-y border-border py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl md:text-5xl font-extrabold text-[#FFA500] text-center mb-10">
            Tailored Solutions for Every Role
          </h2>
          <div className="grid lg:grid-cols-2 gap-8 items-start">
            {/* Left Side - Workflow Visualization */}
            <div className="bg-gray-100 rounded-3xl p-8 md:p-12 space-y-6">
              {workflowData[selectedRole].map((item, index) => (
                <div key={index} className="bg-white rounded-2xl p-6 shadow-lg flex items-center gap-4">
                  {/* Icon */}
                  <div className="w-14 h-14 bg-white rounded-xl flex items-center justify-center flex-shrink-0 border border-gray-200">
                    <svg className="w-8 h-8 text-[#FFA500]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      {getIcon(item.icon)}
                    </svg>
                  </div>

                  {/* Title */}
                  <div className="flex-1">
                    <p className="text-gray-900 font-medium text-base leading-snug">{item.title}</p>
                  </div>

                  <AnimatedCheckmark delay={index * 300} />

                  {/* Badge */}
                  <div className="bg-gray-100 px-4 py-2 rounded-lg shadow-sm flex-shrink-0">
                    <span className="text-sm font-medium text-gray-700 whitespace-nowrap">{item.badge}</span>
                  </div>
                </div>
              ))}
            </div>

            {/* Right Side - Role Cards */}
            <div className="space-y-6">
              <button
                onClick={() => setSelectedRole("builders")}
                className={`w-full text-left rounded-2xl border-2 transition-all duration-300 p-6 cursor-pointer ${
                  selectedRole === "builders"
                    ? "border-green-500 bg-green-900/30 shadow-lg shadow-green-500/20"
                    : "border-green-500 bg-black hover:bg-green-900/20"
                }`}
              >
                <h3 className="text-xl font-semibold text-white mb-3">
                  Builders & Developers – Automate Sales & Cash Flow
                </h3>
                <p className="text-gray-300 text-sm">Faster sales cycles and smoother project cash flow</p>
              </button>

              <button
                onClick={() => setSelectedRole("property")}
                className={`w-full text-left rounded-2xl border-2 transition-all duration-300 p-6 cursor-pointer ${
                  selectedRole === "property"
                    ? "border-green-500 bg-green-900/30 shadow-lg shadow-green-500/20"
                    : "border-transparent bg-black hover:bg-green-900/20"
                }`}
              >
                <h3 className="text-xl font-semibold text-white mb-3">
                  Property Managers – Simplify Tenant Operations
                </h3>
                <p className="text-gray-300 text-sm">Transparent operations and satisfied tenants</p>
              </button>

              <button
                onClick={() => setSelectedRole("brokers")}
                className={`w-full text-left rounded-2xl border-2 transition-all duration-300 p-6 cursor-pointer ${
                  selectedRole === "brokers"
                    ? "border-green-500 bg-green-900/30 shadow-lg shadow-green-500/20"
                    : "border-transparent bg-black hover:bg-green-900/20"
                }`}
              >
                <h3 className="text-xl font-semibold text-white mb-3">Brokers & Agencies – Close Deals Faster</h3>
                <p className="text-gray-300 text-sm">More conversions with less manual work</p>
              </button>

              <button
                onClick={() => setSelectedRole("consultants")}
                className={`w-full text-left rounded-2xl border-2 transition-all duration-300 p-6 cursor-pointer ${
                  selectedRole === "consultants"
                    ? "border-green-500 bg-green-900/30 shadow-lg shadow-green-500/20"
                    : "border-transparent bg-black hover:bg-green-900/20"
                }`}
              >
                <h3 className="text-xl font-semibold text-white mb-3">
                  Consultants & Advisors – Manage Clients Intelligently
                </h3>
                <p className="text-gray-300 text-sm">Stronger relationships and better close rates</p>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Section 3 – One Platform, Endless Possibilities */}
      <section className="relative py-16 md:py-24">
        <div className="absolute inset-0 -z-10">
          <img
            src="/realestatebg.jpg"
            alt="real estate image"
            className="h-full w-full object-cover opacity-15"
            aria-hidden="true"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background/80 to-background/90" />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl md:text-5xl font-extrabold text-primary">One Platform, Endless Possibilities</h2>
          <p className="mt-4 text-lg text-center text-muted-foreground">
            ZeaCRM connects your sales, marketing, service, and property management in one place. No spreadsheets. No
            manual updates. No lost leads.
          </p>
          <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-3 gap-4 text-left">
            {[
              "Real-time deal and task tracking",
              "WhatsApp & email integrations",
              "Auto-reminder and notification workflows",
              "Digital documentation and e-signatures",
              "Centralized project and payment dashboards",
            ].map((item) => (
              <div
                key={item}
                className="p-4 rounded-lg bg-card border border-border text-lg transition-all duration-300"
              >
                {item}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Animation / Visual section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
        <div className="grid md:grid-cols-1 gap-10 items-center">
          <div className="text-center md:text-left">
            <h2 className="text-4xl md:text-5xl text-center font-extrabold text-primary">See AI in Action</h2>
            <p className="mt-4 text-lg text-center text-muted-foreground">
              Engage prospects, automate tasks, and reduce errors with a friendly AI assistant embedded in your
              workflows.
            </p>
          </div>
        </div>
        <AniRealEstate />
      </section>

      {/* Section 4 – Why Real Estate Teams Choose ZeaCRM */}
      <section className="bg-muted/30 border-y border-border py-16 md:py-24 text-center">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl md:text-5xl font-extrabold text-primary text-center">
            Why Real Estate Teams Choose ZeaCRM
          </h2>
          <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-3 gap-6 text-left">
            {[
              ["AI-Powered Insights", "Predict conversion potential and focus on high-value leads."],
              ["Automation-First Workflows", "Eliminate repetitive tasks and save time."],
              ["Data Security & Compliance", "Enterprise-grade encryption and user privacy built-in."],
              ["Industry-Ready Design", "Tailored for property sales, rentals, and management."],
              ["Scalable Growth", "From individual agents to enterprise developers — ZeaCRM scales effortlessly."],
            ].map(([title, desc]) => (
              <div
                key={title as string}
                className="rounded-xl border border-border bg-card p-5 hover:scale-105 hover:shadow-lg transition-all duration-300"
              >
                <h3 className="text-xl font-semibold text-primary text-center">{title as string}</h3>
                <p className="mt-2 text-lg text-muted-foreground">{desc as string}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Section 5 – Ecosystem */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24 text-center">
        <h2 className="text-4xl md:text-5xl font-extrabold text-primary text-center">
          Designed for the Entire Real Estate Ecosystem
        </h2>
        <ul className="mt-8 grid sm:grid-cols-2 lg:grid-cols-3 gap-4 text-left text-lg">
          {[
            "Real Estate Agencies 🏢",
            "Property Developers 🏗️",
            "Builders & Contractors 👷‍♂️🔨",
            "Independent Agents 🧑‍💼",
            "Brokerage Firms 🤝",
            "Rental Managers 🔑🏘️",
            "Commercial Realtors 🏬",
            "Property Consultants 📋🏡",
            "Interior Designers 🛋️🎨",
            "Real Estate Investors 💼📈",
            "Housing Societies 🏘️🏙️",
          ].map((item) => (
            <li
              key={item}
              className="p-4 rounded-lg bg-muted border border-border hover:scale-105 hover:shadow-lg transition-all duration-300"
            >
              {item}
            </li>
          ))}
        </ul>
      </section>

      {/* Section 6 – Closing CTA */}
      <section className="bg-muted/30 border-y border-border py-16 md:py-24 text-center">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl md:text-5xl font-extrabold text-primary text-center">
            Transform the Way You Manage Real Estate
          </h2>
          <p className="mt-4 text-muted-foreground text-lg">
            From first inquiry to final handover — ZeaCRM keeps everything connected, automated, and measurable.
            Experience the next generation of real estate management with complete visibility and control.
          </p>
          <div className="mt-8 flex items-center justify-center gap-4">
            <Button asChild size="lg">
              <Link href="/playbooks/videos">Watch Demo Video</Link>
            </Button>
            <Button asChild size="lg" variant="outline">
              <Link href="/get-started">Start Free Trial</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Section 7 – FAQ */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
        <FAQ
          items={[
            {
              q: "How does ZeaCRM help in real estate lead management?",
              a: "ZeaCRM automates lead capture from portals and ads, scores leads using AI, and schedules personalized follow-ups — ensuring you never miss a potential buyer.",
            },
            {
              q: "Can ZeaCRM handle both sales and property management?",
              a: "Yes, ZeaCRM manages the full real estate lifecycle — from lead generation and sales tracking to rent reminders, maintenance tickets, and tenant communication.",
            },
            {
              q: "Is ZeaCRM suitable for small and large real estate teams?",
              a: "Absolutely. ZeaCRM scales easily — from solo brokers to enterprise developers — offering customizable workflows and role-based access.",
            },
            {
              q: "Does ZeaCRM integrate with WhatsApp and email?",
              a: "Yes, ZeaCRM connects with WhatsApp, Gmail, and other messaging tools to automate client communication and reminders.",
            },
            {
              q: "What makes ZeaCRM different from general CRMs?",
              a: "Unlike generic CRMs, ZeaCRM is built specifically for real estate — combining AI insights, property workflows, and automation to simplify sales, rentals, and management.",
            },
          ]}
        />
      </section>

      <ChatWidget />
      <Footer />
    </>
  )
}
