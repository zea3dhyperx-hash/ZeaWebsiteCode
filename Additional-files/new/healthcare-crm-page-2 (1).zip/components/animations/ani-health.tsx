"use client"
import { DotLottieReact } from "@lottiefiles/dotlottie-react"

export default function AniHealthcare() {
  return (
    <div className="relative w-full aspect-square max-w-lg mx-auto">
      <DotLottieReact
        src="https://lottie.host/eae6df93-0993-4fbc-b80d-cf005a6f75a1/nVGi04eX4n.lottie"
        loop
        autoplay
        className="w-full h-full rounded-xl border border-border bg-card/50"
      />
    </div>
  )
}
