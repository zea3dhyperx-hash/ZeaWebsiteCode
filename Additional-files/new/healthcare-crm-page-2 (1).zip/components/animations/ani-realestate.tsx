"use client"

export default function AniRealEstate() {
  return (
    <div className="w-full rounded-xl border border-border bg-card p-8 my-8">
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center space-y-4">
          <div className="text-6xl">🏢</div>
          <h3 className="text-2xl font-bold text-primary">Real Estate AI Animation</h3>
          <p className="text-muted-foreground">Interactive property management visualization coming soon</p>
        </div>
      </div>
    </div>
  )
}
