"use client"
import { useEffect, useState } from "react"

export function AnimatedCheckmark({ delay = 0 }: { delay?: number }) {
  const [stage, setStage] = useState<"loading" | "complete">("loading")

  useEffect(() => {
    const timer = setTimeout(() => {
      setStage("complete")
    }, delay + 500)

    return () => clearTimeout(timer)
  }, [delay])

  return (
    <div className="relative w-12 h-12 flex items-center justify-center">
      {/* Loading Circle */}
      <svg
        className={`absolute inset-0 w-12 h-12 transition-all duration-200 ${
          stage === "complete" ? "opacity-0 scale-0" : "opacity-100 scale-100"
        }`}
        viewBox="0 0 50 50"
      >
        {/* Background Circle */}
        <circle cx="25" cy="25" r="20" fill="none" stroke="#FFD700" strokeWidth="3" opacity="0.3" />
        <circle
          cx="25"
          cy="25"
          r="20"
          fill="none"
          stroke="#FFA500"
          strokeWidth="3"
          strokeLinecap="round"
          strokeDasharray="125.6"
          strokeDashoffset="125.6"
          transform="rotate(-90 25 25)"
          className="animate-[progress_0.5s_ease-out_forwards]"
        />
      </svg>

      <div
        className={`absolute inset-0 w-12 h-12 bg-gradient-to-br from-green-500 to-green-700 rounded-full flex items-center justify-center transition-all duration-200 ${
          stage === "complete" ? "opacity-100 scale-100 animate-[bounce-in_0.3s_ease-out]" : "opacity-0 scale-0"
        }`}
        style={{
          boxShadow:
            stage === "complete"
              ? "0 4px 20px rgba(34, 197, 94, 0.5), 0 0 40px rgba(34, 197, 94, 0.3), inset 0 1px 3px rgba(255,255,255,0.3)"
              : "none",
        }}
      >
        <svg className="w-7 h-7 text-white drop-shadow-md" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={3.5}
            d="M5 13l4 4L19 7"
            className={stage === "complete" ? "animate-[draw_0.25s_ease-out_forwards]" : ""}
            style={{
              strokeDasharray: 30,
              strokeDashoffset: stage === "complete" ? 0 : 30,
            }}
          />
        </svg>
      </div>
    </div>
  )
}
