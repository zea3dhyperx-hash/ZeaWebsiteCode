"use client"
import { useState } from "react"
import { Button } from "@/components/ui/button"

export default function ChatWidget() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <div className="fixed bottom-4 right-4 z-50">
      {isOpen && (
        <div className="mb-4 w-80 h-96 bg-card border border-border rounded-lg shadow-xl flex flex-col">
          <div className="p-4 border-b border-border flex justify-between items-center">
            <h3 className="font-semibold">Chat with us</h3>
            <button onClick={() => setIsOpen(false)} className="text-muted-foreground hover:text-foreground">
              ✕
            </button>
          </div>
          <div className="flex-1 p-4 overflow-y-auto">
            <p className="text-sm text-muted-foreground">How can we help you today?</p>
          </div>
          <div className="p-4 border-t border-border">
            <input
              type="text"
              placeholder="Type a message..."
              className="w-full px-3 py-2 bg-background border border-border rounded-md"
            />
          </div>
        </div>
      )}
      <Button onClick={() => setIsOpen(!isOpen)} size="lg" className="rounded-full h-14 w-14 shadow-lg">
        💬
      </Button>
    </div>
  )
}
