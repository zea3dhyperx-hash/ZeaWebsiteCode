"use client"
import { useState } from "react"

interface FAQItem {
  q: string
  a: string
}

interface FAQProps {
  items: FAQItem[]
}

export default function FAQ({ items }: FAQProps) {
  const [openIndex, setOpenIndex] = useState<number | null>(null)

  return (
    <div className="max-w-3xl mx-auto">
      <h2 className="text-3xl md:text-4xl font-bold text-center mb-8 text-primary">Frequently Asked Questions</h2>
      <div className="space-y-4">
        {items.map((item, index) => (
          <div key={index} className="border border-border rounded-lg overflow-hidden bg-card">
            <button
              onClick={() => setOpenIndex(openIndex === index ? null : index)}
              className="w-full px-6 py-4 text-left flex justify-between items-center hover:bg-muted/50 transition-colors"
            >
              <span className="font-semibold text-foreground">{item.q}</span>
              <span className={`transition-transform ${openIndex === index ? "rotate-180" : ""}`}>▼</span>
            </button>
            {openIndex === index && (
              <div className="px-6 py-4 border-t border-border bg-muted/30">
                <p className="text-muted-foreground">{item.a}</p>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}
