"use client"

export default function AniEdu() {
  return (
    <div className="relative w-full h-full min-h-[400px] flex items-center justify-center">
      <div className="relative w-full max-w-4xl aspect-[3/2]">
        {/* Animated gradient background */}
        <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-amber-400/20 via-pink-500/20 to-indigo-600/20 animate-pulse" />

        <div className="absolute inset-0 flex items-center justify-center">
          <video className="w-full h-full object-cover rounded-2xl" autoPlay loop muted playsInline>
            <source src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/grok-video-57ccf083-5ca7-43c5-b1cc-5961b0607c4f-sJj315ejcd4kRPfLwsWtz3OCspqlXY.mp4" type="video/mp4" />
          </video>
        </div>
      </div>
    </div>
  )
}
