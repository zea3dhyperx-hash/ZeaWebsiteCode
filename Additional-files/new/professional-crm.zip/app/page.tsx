"use client"
import { useEffect, useRef, useState } from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { AniProf } from "@/components/animations/ani-prof"
import { Building2, Megaphone, Scale, DollarSign, Users, Compass, Briefcase, Dumbbell, Home } from "lucide-react"

export default function ProfessionalServicesCRM() {
  const [expanded, setExpanded] = useState(false)
  const [lockedOpen, setLockedOpen] = useState(false)
  const [videoSrc, setVideoSrc] = useState("")
  const iframeRef = useRef<HTMLIFrameElement>(null)
  const panelRef = useRef<HTMLDivElement>(null)
  const [panelHeight, setPanelHeight] = useState(0)
  const hoverTimeoutRef = useRef<NodeJS.Timeout | null>(null)

  useEffect(() => {
    if (panelRef.current) setPanelHeight(panelRef.current.scrollHeight)
  }, [expanded])

  useEffect(() => {
    return () => {
      if (hoverTimeoutRef.current) {
        clearTimeout(hoverTimeoutRef.current)
      }
    }
  }, [])

  useEffect(() => {
    setVideoSrc("https://www.youtube.com/embed/IGLw-PVrPUg?si=f0UWGOOpXwgjankN")
  }, [])

  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (!event.origin.includes("youtube.com")) return
      let data: any = event.data
      try {
        if (typeof data === "string") data = JSON.parse(data)
      } catch {
        return
      }
      if (!data?.event) return
      const state = data.info?.playerState !== undefined ? data.info.playerState : data.data
      if (state === 1) {
        setLockedOpen(true)
        setExpanded(true)
      } else if (state === 0 || state === 2) {
        setLockedOpen(false)
      }
    }
    window.addEventListener("message", handleMessage)
    return () => window.removeEventListener("message", handleMessage)
  }, [])

  const onIframeLoad = () => {
    const win = iframeRef.current?.contentWindow
    if (!win) return
    try {
      win.postMessage(JSON.stringify({ event: "listening" }), "*")
      win.postMessage(JSON.stringify({ event: "command", func: "addEventListener", args: ["onStateChange"] }), "*")
    } catch {}
  }

  useEffect(() => {
    if (!expanded && iframeRef.current && videoSrc) {
      iframeRef.current.contentWindow?.postMessage(
        JSON.stringify({ event: "command", func: "stopVideo", args: [] }),
        "*",
      )
      iframeRef.current.src = videoSrc
    }
  }, [expanded, videoSrc])

  return (
    <>
      <Header />

      {/* Video section */}
      <section
        className="bg-gradient-to-r from-amber-400 via-pink-500 to-indigo-600 text-slate-900"
        onMouseEnter={() => {
          if (hoverTimeoutRef.current) {
            clearTimeout(hoverTimeoutRef.current)
          }
          hoverTimeoutRef.current = setTimeout(() => {
            setExpanded(true)
          }, 0)
        }}
        onMouseLeave={(e) => {
          if (hoverTimeoutRef.current) {
            clearTimeout(hoverTimeoutRef.current)
            hoverTimeoutRef.current = null
          }

          if (lockedOpen) return

          const relatedTarget = e.relatedTarget as HTMLElement | null

          if (relatedTarget === null || (iframeRef.current && iframeRef.current.contains(relatedTarget))) {
            return
          }

          if (relatedTarget && typeof relatedTarget.closest === "function") {
            if (relatedTarget.closest("header")) {
              setExpanded(false)
              return
            }
          }
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <button
            onFocus={() => setExpanded(true)}
            className="w-full py-3 font-semibold tracking-wide flex items-center justify-center gap-2"
            aria-expanded={expanded}
          >
            {"Watch me"}
            <span className={`transition-transform ${expanded ? "rotate-180" : "rotate-0"}`}>{"⏷"}</span>
          </button>
        </div>
        <div
          style={{ maxHeight: expanded ? panelHeight : 0 }}
          className="transition-[max-height] duration-500 ease-out overflow-hidden bg-slate-950 border-t border-black/20"
        >
          <div ref={panelRef} className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div className="relative aspect-video bg-slate-800 rounded-xl overflow-hidden border border-slate-800">
              <button
                aria-label="Close video"
                onClick={() => {
                  setExpanded(false)
                  setLockedOpen(false)
                }}
                className="absolute top-2 right-2 z-10 inline-flex h-9 w-9 items-center justify-center rounded-md bg-black/50 text-white hover:bg-black/70 transition"
              >
                {"✕"}
              </button>
              {videoSrc && (
                <iframe
                  ref={iframeRef}
                  className="w-full h-full"
                  src={videoSrc}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                  title="ZeaCRM Professional Services Video"
                  onLoad={onIframeLoad}
                />
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Hero */}
      <section className="border-b bg-background py-16 md:py-24 border-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid md:grid-cols-2 gap-10 items-center">
          <div className="text-center md:text-left">
            <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight text-[rgba(223,168,34,1)]">
              {"Professional Services Automation"}
            </h1>
            <p className="mt-3 text-lg text-foreground">
              {"Smarter Client, Project, and Workflow Management – Powered by AI"}
            </p>
            <p className="mt-3 text-lg text-foreground">
              {
                "ZeaCRM helps consultants, agencies, and professional service firms automate every client interaction — from proposal to payment. Manage deals, projects, and communication effortlessly while your AI assistant keeps operations running smoothly."
              }
            </p>
            <div className="mt-8 flex gap-4 justify-center md:justify-start">
              <Button className="bg-[rgba(223,168,34,1)] text-background" asChild size="lg">
                <Link href="/playbooks/videos">{"Watch Demo Video"}</Link>
              </Button>
              <Button className="border-muted-foreground bg-transparent" asChild size="lg" variant="outline">
                <Link href="/get-started">{"Start Free Trial"}</Link>
              </Button>
            </div>
          </div>
          <div className="rounded-xl border border-border overflow-hidden bg-card">
            <video className="w-full h-full object-cover" controls autoPlay muted loop playsInline>
              <source src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/grok-video-8d493761-4b05-46fc-8dc7-c056c661b2cf-cXXEP9q4ZeCJllxSWPX7i1SjuHzlwS.mp4" type="video/mp4" />
              Your browser does not support the video tag.
            </video>
          </div>
        </div>
      </section>

      {/* Smart Solutions */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
        <h2 className="text-4xl md:text-5xl font-extrabold text-center text-[rgba(223,168,34,1)]">
          {"Smart Solutions for Every Service Professional"}
        </h2>
        <div className="mt-10 grid md:grid-cols-3 gap-6">
          <div className="group rounded-xl border border-border p-6 transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:scale-105 bg-[rgba(223,168,34,1)]">
            <h3 className="text-xl font-semibold text-center">{"Consultants & Agencies"}</h3>
            <ul className="mt-4 space-y-2 text-background">
              <li>{"Automated proposal & invoice generation"}</li>
              <li>{"Appointment scheduling with reminders"}</li>
              <li>{"AI follow-ups that nurture clients automatically"}</li>
            </ul>
            <p className="mt-4 text-sm">{"📈 Result: Faster deals & stronger relationships"}</p>
          </div>
          <div className="group rounded-xl border border-border p-6 transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:scale-105 bg-[rgba(223,168,34,1)]">
            <h3 className="text-xl font-semibold text-center">{"IT & SaaS Providers"}</h3>
            <ul className="mt-4 space-y-2 text-background">
              <li>{"Auto demo/trial scheduling & follow-up"}</li>
              <li>{"Subscription renewals & billing reminders"}</li>
              <li>{"CRM-integrated support ticket tracking"}</li>
            </ul>
            <p className="mt-4 text-sm">{"📈 Result: Improved customer retention & smoother onboarding"}</p>
          </div>
          <div className="group rounded-xl border border-border p-6 transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:scale-105 bg-[rgba(223,168,34,1)]">
            <h3 className="text-xl font-semibold text-center">{"Legal & Accounting Firms"}</h3>
            <ul className="mt-4 space-y-2 text-background">
              <li>{"Workflow automation for cases & projects"}</li>
              <li>{"Compliance alerts & filing deadline reminders"}</li>
              <li>{"Secure document management with e-signing"}</li>
            </ul>
            <p className="mt-4 text-sm">{"📈 Result: Fewer errors, more billable hours"}</p>
          </div>
        </div>
      </section>

      {/* Why ZeaCRM */}
      <section className="border-y py-16 md:py-24 bg-neutral-800 border-background">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl md:text-5xl font-extrabold text-[rgba(223,168,34,1)]">{"Why ZeaCRM?"}</h2>
          <p className="mt-4 text-lg text-foreground">
            {"ZeaCRM is built on five core pillars to transform your professional service operations:"}
          </p>
          <ul className="mt-8 grid sm:grid-cols-2 gap-4 text-left">
            <li className="p-4 rounded-lg bg-card border border-border hover:scale-105 hover:shadow-lg transition-all duration-300 text-background">
              {"1. AI-Powered Intelligence – Predictive insights, lead scoring & automation triggers."}
            </li>
            <li className="p-4 rounded-lg bg-card border border-border hover:scale-105 hover:shadow-lg transition-all duration-300 text-background">
              {"2. Automation-First Design – Reduce manual tasks and human follow-ups."}
            </li>
            <li className="p-4 rounded-lg bg-card border border-border hover:scale-105 hover:shadow-lg transition-all duration-300 text-background">
              {"3. Secure & Compliant – Enterprise-grade data encryption & privacy."}
            </li>
            <li className="p-4 rounded-lg bg-card border border-border hover:scale-105 hover:shadow-lg transition-all duration-300 text-background">
              {"4. Industry-Ready – Pre-built modules for every service vertical."}
            </li>
            <li className="p-4 rounded-lg bg-card border border-border hover:scale-105 hover:shadow-lg transition-all duration-300 text-background">
              {"5. Proven Impact – Faster deals, stronger relationships, higher ROI."}
            </li>
          </ul>
          <p className="mt-6 text-[rgba(223,168,34,1)]">
            {
              "Your industry is evolving — your CRM should evolve with it. ZeaCRM brings precision, automation, and intelligence into every client interaction."
            }
          </p>
        </div>
      </section>

      {/* Who We Help */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
        <h2 className="text-4xl md:text-5xl font-extrabold text-center text-[rgba(223,168,34,1)]">{"Who We Help"}</h2>
        <div className="mt-8 text-center mb-4 mx-auto">
          <p className="text-lg mb-8 text-foreground">{"Better care. Smarter spending. Less burnout."}</p>
          <div className="rounded-2xl border border-border p-8 md:p-12 bg-[rgba(223,168,34,1)] opacity-100 text-popover-foreground">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <div className="text-left text-background">
                <Building2 className="w-12 h-12 mb-4 text-black" strokeWidth={1.5} />
                <h3 className="text-xl font-semibold mb-2">{"Consulting Firms"}</h3>
                <p className="text-sm text-black/80">{"Manage clients, proposals, and follow-ups efficiently."}</p>
              </div>

              <div className="text-left">
                <Megaphone className="w-12 h-12 mb-4 text-black" strokeWidth={1.5} />
                <h3 className="text-xl font-semibold mb-2 text-background">{"Marketing & Creative Agencies"}</h3>
                <p className="text-sm text-black/80">{"Automate reporting, campaigns, and approvals."}</p>
              </div>

              <div className="text-left">
                <Scale className="w-12 h-12 mb-4 text-black" strokeWidth={1.5} />
                <h3 className="text-xl font-semibold mb-2 text-background">{"Legal Practices"}</h3>
                <p className="text-sm text-black/80">{"Streamline case management and client communication."}</p>
              </div>

              <div className="text-left">
                <div className="w-12 h-12 rounded-full border-2 border-black flex items-center justify-center mb-4">
                  <DollarSign className="w-7 h-7 text-black" strokeWidth={2} />
                </div>
                <h3 className="text-xl font-semibold mb-2 text-background">{"Financial & Accounting Firms"}</h3>
                <p className="text-sm text-black/80">{"Automate billing, renewals, and reminders."}</p>
              </div>

              <div className="text-left">
                <div className="w-12 h-12 rounded-full border-2 border-black flex items-center justify-center mb-4">
                  <Users className="w-7 h-7 text-black" strokeWidth={1.5} />
                </div>
                <h3 className="text-xl font-semibold mb-2 text-background">{"IT & Software Providers"}</h3>
                <p className="text-sm text-black/80">{"Manage tickets, client onboarding, and renewals."}</p>
              </div>

              <div className="text-left">
                <Compass className="w-12 h-12 mb-4 text-black" strokeWidth={1.5} />
                <h3 className="text-xl font-semibold mb-2 text-background">{"Architects & Designers"}</h3>
                <p className="text-sm text-black/80">{"Track leads, consultations, and project milestones."}</p>
              </div>

              <div className="text-left">
                <Briefcase className="w-12 h-12 mb-4 text-black" strokeWidth={1.5} />
                <h3 className="text-xl font-semibold mb-2 text-background">{"Recruitment & HR Agencies"}</h3>
                <p className="text-sm text-black/80">{"Simplify candidate and client tracking."}</p>
              </div>

              <div className="text-left">
                <Dumbbell className="w-12 h-12 mb-4 text-black" strokeWidth={1.5} />
                <h3 className="text-xl font-semibold mb-2 text-background">{"Trainers & Coaches"}</h3>
                <p className="text-sm text-black/80">{"Manage sessions, enrollments, and results."}</p>
              </div>

              <div className="text-left">
                <Home className="w-12 h-12 mb-4 text-black" strokeWidth={1.5} />
                <h3 className="text-xl font-semibold mb-2 text-background">{"Event & PR Agencies"}</h3>
                <p className="text-sm text-black/80">{"Coordinate vendors, client briefs, and outcomes."}</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* All-in-One Platform */}
      <section className="bg-background border-t py-16 md:py-24 border-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid md:grid-cols-2 gap-10 items-center">
          <div>
            <h2 className="text-4xl md:text-5xl font-extrabold text-[rgba(223,168,34,1)]">
              {"All-in-One Platform for Client-Focused Success"}
            </h2>
            <p className="mt-4 text-lg text-foreground">
              {
                "ZeaCRM brings structure, clarity, and automation to your entire client lifecycle. Every proposal, project, and conversation is connected through AI — ensuring smooth workflows, faster decisions, and measurable growth."
              }
            </p>
            <div className="mt-4">
              <p>{"Empower your team to:"}</p>
              <ul className="mt-3 space-y-2 text-lg text-foreground">
                <li>{"✅ Collaborate in real time"}</li>
                <li>{"✅ Automate repetitive reminders"}</li>
                <li>{"✅ Centralize all client data securely"}</li>
                <li>{"✅ Track progress with AI insights"}</li>
              </ul>
              <p className="mt-3">
                {"Deliver high-quality service while saving time, reducing errors, and increasing profit margins."}
              </p>
            </div>
          </div>
          <div className="rounded-xl p-0 overflow-hidden">
            <AniProf />
          </div>
        </div>
      </section>

      {/* Automation Flow */}
      <section className="border-y py-16 md:py-24 bg-neutral-800 border-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl md:text-5xl font-extrabold text-center text-[rgba(223,168,34,1)]">{"Automation Flow"}</h2>
          <div className="mt-10 grid md:grid-cols-5 gap-4">
            {[
              { t: "Capture", d: "Forms/Integrations" },
              { t: "Score", d: "AI Priority" },
              { t: "Assign", d: "Auto Routing" },
              { t: "Act", d: "Sequences" },
              { t: "Measure", d: "Dashboards" },
            ].map((n, i) => (
              <div
                key={n.t}
                className="relative p-6 rounded-xl border border-border bg-card overflow-hidden hover:scale-105 hover:shadow-lg transition-all duration-300"
              >
                <div className="absolute inset-0 animate-[pulse_2s_ease-in-out_infinite] bg-gradient-to-r from-transparent via-primary/5 to-transparent bg-[rgba(223,168,34,1)]" />
                <h3 className="relative text-xl font-semibold text-background">{n.t}</h3>
                <p className="relative text-background">{n.d}</p>
                {i < 4 && (
                  <div className="hidden md:block absolute -right-5 top-1/2 -translate-y-1/2 text-3xl">{"→"}</div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-primary text-background py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl md:text-5xl font-extrabold text-[rgba(223,168,34,1)]">{"Let's Simplify Your Client Management"}</h2>
          <p className="mt-4 text-lg text-foreground">
            {
              "Experience the next generation of CRM automation built specifically for service-driven businesses. Let ZeaCRM handle the busywork — so you can focus on building relationships that last."
            }
          </p>
          <div className="mt-8 flex gap-4 justify-center">
            <Button asChild size="lg" variant="secondary">
              <Link href="/playbooks/videos">{"Watch Demo Video"}</Link>
            </Button>
            <Button asChild size="lg" variant="outline" className="bg-transparent text-foreground border-foreground">
              <Link href="/get-started">{"Start Free Trial"}</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* FAQs */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h2 className="text-3xl md:text-4xl font-extrabold text-center text-[rgba(223,168,34,1)]">{"FAQs"}</h2>
        <div className="mt-8 space-y-6 bg-background text-foreground">
          <details className="rounded-lg border border-border p-4 bg-background" open>
            <summary className="cursor-pointer font-semibold text-[rgba(223,168,34,1)]">
              {"1. How does AI automation help consultants and agencies?"}
            </summary>
            <p className="mt-2 text-foreground">
              {
                "AI automation in ZeaCRM streamlines repetitive tasks like follow-ups, reminders, and reporting — allowing consultants and agencies to focus on strategy and client growth."
              }
            </p>
          </details>
          <details className="rounded-lg border border-border p-4 bg-background">
            <summary className="cursor-pointer font-semibold text-[rgba(223,168,34,1)]">
              {"2. Can ZeaCRM integrate with other tools used by professional service firms?"}
            </summary>
            <p className="mt-2 text-muted-foreground">
              {
                "Yes. ZeaCRM connects with your existing tools, ensuring a unified workflow across billing, scheduling, and communication without switching platforms."
              }
            </p>
          </details>
          <details className="rounded-lg border border-border p-4 bg-background">
            <summary className="cursor-pointer font-semibold text-[rgba(223,168,34,1)]">
              {"3. Is ZeaCRM suitable for both small agencies and large consulting firms?"}
            </summary>
            <p className="mt-2 text-muted-foreground">
              {
                "Absolutely. ZeaCRM scales effortlessly — whether you're a solo consultant or a multi-branch agency managing hundreds of clients."
              }
            </p>
          </details>
          <details className="rounded-lg border border-border p-4 bg-background">
            <summary className="cursor-pointer font-semibold text-[rgba(223,168,34,1)]">{"4. What industries benefit most from ZeaCRM?"}</summary>
            <p className="mt-2 text-muted-foreground">
              {
                "ZeaCRM is ideal for consulting, marketing, legal, accounting, IT services, architecture, recruitment, coaching, and event management — any client-driven business."
              }
            </p>
          </details>
          <details className="rounded-lg border border-border p-4 bg-background">
            <summary className="cursor-pointer font-semibold text-[rgba(223,168,34,1)]">
              {"5. How does ZeaCRM help with project management?"}
            </summary>
            <p className="mt-2 text-muted-foreground">
              {
                "ZeaCRM centralizes tasks, milestones, and team collaboration in one place — keeping everyone aligned without switching between tools."
              }
            </p>
          </details>
        </div>
      </section>

      <Footer />
    </>
  )
}
