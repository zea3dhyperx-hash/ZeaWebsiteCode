"use client"
import { useEffect, useRef, useState } from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import AniRetail from "@/components/animations/ani-retail"

export default function RetailEcomCRM() {
  const [expanded, setExpanded] = useState(false)
  const [lockedOpen, setLockedOpen] = useState(false)
  const [videoSrc, setVideoSrc] = useState("")
  const iframeRef = useRef<HTMLIFrameElement>(null)
  const panelRef = useRef<HTMLDivElement>(null)
  const [panelHeight, setPanelHeight] = useState(0)
  const hoverTimeoutRef = useRef<NodeJS.Timeout | null>(null)

  useEffect(() => {
    if (panelRef.current) setPanelHeight(panelRef.current.scrollHeight)
  }, [expanded])

  useEffect(() => {
    return () => {
      if (hoverTimeoutRef.current) {
        clearTimeout(hoverTimeoutRef.current)
      }
    }
  }, [])

  useEffect(() => {
    setVideoSrc("https://www.youtube.com/embed/F67s8-t_Xls?si=CkvsMfGrcXkt3SDh")
  }, [])

  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (!event.origin.includes("youtube.com")) return
      let data: any = event.data
      try {
        if (typeof data === "string") data = JSON.parse(data)
      } catch {
        return
      }
      if (!data?.event) return
      const state = data.info?.playerState !== undefined ? data.info.playerState : data.data
      if (state === 1) {
        setLockedOpen(true)
        setExpanded(true)
      } else if (state === 0 || state === 2) {
        setLockedOpen(false)
      }
    }
    window.addEventListener("message", handleMessage)
    return () => window.removeEventListener("message", handleMessage)
  }, [])

  const onIframeLoad = () => {
    const win = iframeRef.current?.contentWindow
    if (!win) return
    try {
      win.postMessage(JSON.stringify({ event: "listening" }), "*")
      win.postMessage(JSON.stringify({ event: "command", func: "addEventListener", args: ["onStateChange"] }), "*")
    } catch {}
  }

  useEffect(() => {
    if (!expanded && iframeRef.current && videoSrc) {
      iframeRef.current.contentWindow?.postMessage(
        JSON.stringify({ event: "command", func: "stopVideo", args: [] }),
        "*",
      )
      iframeRef.current.src = videoSrc
    }
  }, [expanded, videoSrc])

  return (
    <>
      <Header />

      {/* Video section */}
      <section
        className="bg-gradient-to-r from-amber-400 via-pink-500 to-indigo-600 text-slate-900"
        onMouseEnter={() => {
          if (hoverTimeoutRef.current) {
            clearTimeout(hoverTimeoutRef.current)
          }
          hoverTimeoutRef.current = setTimeout(() => {
            setExpanded(true)
          }, 0)
        }}
        onMouseLeave={(e) => {
          if (hoverTimeoutRef.current) {
            clearTimeout(hoverTimeoutRef.current)
            hoverTimeoutRef.current = null
          }

          if (lockedOpen) return

          const relatedTarget = e.relatedTarget as HTMLElement | null

          if (relatedTarget === null || (iframeRef.current && iframeRef.current.contains(relatedTarget))) {
            return
          }

          if (relatedTarget && typeof relatedTarget.closest === "function") {
            if (relatedTarget.closest("header")) {
              setExpanded(false)
              return
            }
          }
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <button
            onFocus={() => setExpanded(true)}
            className="w-full py-3 font-semibold tracking-wide flex items-center justify-center gap-2"
            aria-expanded={expanded}
          >
            Watch me
            <span className={`transition-transform ${expanded ? "rotate-180" : "rotate-0"}`}>⏷</span>
          </button>
        </div>
        <div
          style={{ maxHeight: expanded ? panelHeight : 0 }}
          className="transition-[max-height] duration-500 ease-out overflow-hidden bg-slate-950 border-t border-black/20"
        >
          <div ref={panelRef} className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div className="relative aspect-video bg-slate-800 rounded-xl overflow-hidden border border-slate-800">
              <button
                aria-label="Close video"
                onClick={() => {
                  setExpanded(false)
                  setLockedOpen(false)
                }}
                className="absolute top-2 right-2 z-10 inline-flex h-9 w-9 items-center justify-center rounded-md bg-black/50 text-white hover:bg-black/70 transition"
              >
                ✕
              </button>
              {videoSrc && (
                <iframe
                  ref={iframeRef}
                  className="w-full h-full"
                  src={videoSrc}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                  title="ZeaCRM Retail & E‑Commerce Video"
                  onLoad={onIframeLoad}
                />
              )}
            </div>
          </div>
          <div className="rounded-xl border border-border overflow-hidden bg-card">
            <video className="w-full h-auto" controls autoPlay muted loop playsInline>
              <source src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/grok-video-66fc1576-fe90-4b85-877c-186c4c7c6ca1-iY2kJjWcoyYzOVbLzWLhYpravliowa.mp4" type="video/mp4" />
              Your browser does not support the video tag.
            </video>
          </div>
        </div>
      </section>

      {/* Hero */}
      <section className="border-b border-border bg-background py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid md:grid-cols-2 gap-10 items-center">
          <div className="text-center md:text-left">
            <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight text-balance text-[rgba(223,168,34,1)]">
              Retail & E-Commerce CRM
            </h1>
            <p className="mt-3 text-muted-foreground text-lg">Boost Sales. Build Loyalty. Automate Everything.</p>
            <p className="mt-3 text-muted-foreground text-lg">
              Deliver seamless, personalized shopping experiences with ZeaCRM — the AI-powered platform that connects
              your stores, customers, and campaigns in one place.
            </p>
            <p className="mt-3 text-muted-foreground text-lg">
              Automate marketing, track orders, manage loyalty, and grow globally — all from a single dashboard.
            </p>
            <p className="mt-3 text-muted-foreground text-lg">
              🎯 Transform browsing into buying with automation that never sleeps.
            </p>
            <div className="mt-8 flex gap-4 justify-center md:justify-start">
              <Button className="bg-[rgba(223,168,34,1)] text-background" asChild size="lg">
                <Link href="/playbooks/videos">Watch Demo Video</Link>
              </Button>
              <Button className="border-muted-foreground" asChild size="lg" variant="outline">
                <Link href="/get-started">Start Free Trial</Link>
              </Button>
            </div>
          </div>
          <div className="rounded-xl border border-border overflow-hidden bg-card">
            <video className="w-full h-auto" controls autoPlay muted loop playsInline>
              <source src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/grok-video-66fc1576-fe90-4b85-877c-186c4c7c6ca1-iY2kJjWcoyYzOVbLzWLhYpravliowa.mp4" type="video/mp4" />
              Your browser does not support the video tag.
            </video>
          </div>
        </div>
      </section>

      {/* Solutions by Business Type */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
        <h2 className="text-4xl md:text-5xl font-extrabold text-primary text-center text-balance">
          Solutions by Business Type
        </h2>
        <div className="mt-10 grid md:grid-cols-3 gap-6">
          <div className="group rounded-xl border border-border p-6 transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:scale-105 bg-[rgba(223,168,34,1)]">
            <h3 className="text-xl font-semibold text-center">Online Stores</h3>
            <ul className="mt-4 space-y-2 text-background">
              <li>Automated order confirmations & real-time shipping updates via WhatsApp and Email</li>
              <li>AI-driven abandoned cart recovery & personalized promotions</li>
              <li>Seamless digital payments and billing workflows</li>
            </ul>
            <p className="mt-4 text-sm">📈 Result: More conversions and repeat orders</p>
          </div>
          <div className="group rounded-xl border border-border p-6 transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:scale-105 bg-[rgba(223,168,34,1)]">
            <h3 className="text-xl font-semibold text-center">Supermarkets & Retail Chains</h3>
            <ul className="mt-4 space-y-2 text-background">
              <li>Centralized inventory sync with auto low-stock alerts</li>
              <li>Automated loyalty rewards & personalized customer offers</li>
              <li>Feedback campaigns that boost satisfaction and retention</li>
            </ul>
            <p className="mt-4 text-sm">📈 Result: More repeat buyers and optimized operations</p>
          </div>
          <div className="group rounded-xl border border-border p-6 transition-all duration-300 hover:-translate-y-1 hover:shadow-lg hover:scale-105 bg-[rgba(223,168,34,1)]">
            <h3 className="text-xl font-semibold text-center">Franchise Outlets</h3>
            <ul className="mt-4 space-y-2 text-background">
              <li>Unified CRM and marketing dashboards across all branches</li>
              <li>Royalty tracking and performance analytics</li>
              <li>Consistent customer engagement & brand experience</li>
            </ul>
            <p className="mt-4 text-sm">📈 Result: Stronger brand presence and predictable growth</p>
          </div>
        </div>
      </section>

      {/* AI-Powered CRM */}
      <section className="bg-muted/30 border-y border-border py-16 md:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl md:text-5xl font-extrabold text-balance text-[rgba(223,168,34,1)]">
            AI‑Powered CRM for Modern Commerce
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">Smarter engagement across every channel</p>
          <p className="mt-3 text-muted-foreground text-lg max-w-4xl mx-auto">
            ZeaCRM bridges online and offline retail with automation and intelligence. Manage all customer interactions,
            marketing campaigns, and order journeys — all in one place. Our AI predicts buying behavior, suggests
            next-best offers, and ensures every message hits at the perfect moment.
          </p>
        </div>
      </section>

      {/* Who We Help */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
        <h2 className="text-4xl md:text-5xl font-extrabold text-center text-balance text-[rgba(223,168,34,1)]">Who We Help</h2>
        <div className="mt-8 space-y-2 text-center animate-in fade-in slide-in-from-bottom-4 duration-1000 ease-out opacity-0 [animation-fill-mode:forwards] hover:scale-[1.01] transition-transform">
          <p className="pb-5 leading-9">ZeaCRM empowers the full retail ecosystem:</p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 text-left leading-8">
            <div className="flex gap-4 items-start animate-in fade-in slide-in-from-bottom-4 duration-700 delay-100">
              <div className="text-5xl text-[#DFA822] flex-shrink-0">🏪</div>
              <div>
                <h3 className="text-lg font-semibold text-foreground">Unify data</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Automate campaigns, order updates & customer feedback.
                </p>
              </div>
            </div>

            <div className="flex gap-4 items-start animate-in fade-in slide-in-from-bottom-4 duration-700 delay-200">
              <div className="text-5xl text-[#DFA822] flex-shrink-0">🏬</div>
              <div>
                <h3 className="text-lg font-semibold text-foreground">Retail Chains</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Manage multiple locations with unified customer data.
                </p>
              </div>
            </div>

            <div className="flex gap-4 items-start animate-in fade-in slide-in-from-bottom-4 duration-700 delay-300">
              <div className="text-5xl text-[#DFA822] flex-shrink-0">💎</div>
              <div>
                <h3 className="text-lg font-semibold text-foreground">Fashion & Apparel Brands</h3>
                <p className="text-sm text-muted-foreground mt-1">Personalize recommendations & loyalty rewards.</p>
              </div>
            </div>

            <div className="flex gap-4 items-start animate-in fade-in slide-in-from-bottom-4 duration-700 delay-[400ms]">
              <div className="text-5xl text-[#DFA822] flex-shrink-0">🛒</div>
              <div>
                <h3 className="text-lg font-semibold text-foreground">Grocery & FMCG Stores</h3>
                <p className="text-sm text-muted-foreground mt-1">Enable automated reorders & product notifications.</p>
              </div>
            </div>

            <div className="flex gap-4 items-start animate-in fade-in slide-in-from-bottom-4 duration-700 delay-500">
              <div className="text-5xl text-[#DFA822] flex-shrink-0">📱</div>
              <div>
                <h3 className="text-lg font-semibold text-foreground">Electronics Retailers</h3>
                <p className="text-sm text-muted-foreground mt-1">Manage warranties, repairs & service tickets.</p>
              </div>
            </div>

            <div className="flex gap-4 items-start animate-in fade-in slide-in-from-bottom-4 duration-700 delay-600">
              <div className="text-5xl text-[#DFA822] flex-shrink-0">💍</div>
              <div>
                <h3 className="text-lg font-semibold text-foreground">Luxury & Lifestyle Brands</h3>
                <p className="text-sm text-muted-foreground mt-1">Design VIP programs & exclusive engagement.</p>
              </div>
            </div>

            <div className="flex gap-4 items-start animate-in fade-in slide-in-from-bottom-4 duration-700 delay-700">
              <div className="text-5xl text-[#DFA822] flex-shrink-0">🌸</div>
              <div>
                <h3 className="text-lg font-semibold text-foreground">Beauty & Wellness Brands</h3>
                <p className="text-sm text-muted-foreground mt-1">Automate reminders & after-care follow-ups.</p>
              </div>
            </div>

            <div className="flex gap-4 items-start animate-in fade-in slide-in-from-bottom-4 duration-700 delay-800">
              <div className="text-5xl text-[#DFA822] flex-shrink-0">🏠</div>
              <div>
                <h3 className="text-lg font-semibold text-foreground">Home & Interior Stores</h3>
                <p className="text-sm text-muted-foreground mt-1">Track high-value projects & lead pipelines.</p>
              </div>
            </div>

            <div className="flex gap-4 items-start animate-in fade-in slide-in-from-bottom-4 duration-700 delay-900">
              <div className="text-5xl text-[#DFA822] flex-shrink-0">💻</div>
              <div>
                <h3 className="text-lg font-semibold text-foreground">E-Commerce Marketplaces</h3>
                <p className="text-sm text-muted-foreground mt-1">Connect chat, feedback, and customer support.</p>
              </div>
            </div>

            <div className="flex gap-4 items-start animate-in fade-in slide-in-from-bottom-4 duration-700 delay-1000">
              <div className="text-5xl text-[#DFA822] flex-shrink-0">▶️</div>
              <div>
                <h3 className="text-lg font-semibold text-foreground">Subscription Businesses</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Automate renewals, upsells, and recurring engagement.
                </p>
              </div>
            </div>

            <div className="flex gap-4 items-start animate-in fade-in slide-in-from-bottom-4 duration-700 delay-1100">
              <div className="text-5xl text-[#DFA822] flex-shrink-0">🏪</div>
              <div>
                <h3 className="text-lg font-semibold text-foreground">Franchise Networks</h3>
                <p className="text-sm text-muted-foreground mt-1">
                  Maintain centralized control over customer experience.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* All-in-One Platform */}
      <section className="bg-background border-t border-border py-16 md:py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid md:grid-cols-2 items-center gap-9">
          <div className="text-center">
            <h2 className="text-4xl font-extrabold text-balance md:text-4xl text-left text-[rgba(223,168,34,1)]">
              All‑in‑One Platform for Retail Growth
            </h2>
            <ul className="mt-6 space-y-3 text-muted-foreground text-lg text-left">
              <li>🧭 Real-time analytics & reporting</li>
              <li>🤖 Smart automation for every workflow</li>
              <li>💬 Integrated WhatsApp, Email & SMS engagement</li>
              <li>💳 Payment gateway and order sync integration</li>
              <li>🛒 Shopify, WooCommerce, and ERP compatibility</li>
            </ul>
            <p className="mt-4 text-sm text-left">📈 Result: Connected teams, loyal customers, and accelerated revenue growth.</p>
          </div>
          <AniRetail />
        </div>
      </section>

      {/* Why ZeaCRM */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
        <h2 className="text-4xl md:text-5xl font-extrabold text-center text-balance text-[rgba(223,168,34,1)]">Why ZeaCRM?</h2>
        <div className="md:w-2/3 mx-auto">
          <p className="text-center py-2 text-muted-foreground text-lg">
            Our platform is built on five foundations that drive retail transformation:
          </p>
          <ul className="mt-4 space-y-2 justify-center bg-muted rounded-lg px-8 md:px-20 py-10">
            <li>• AI-Powered — Predict, personalize, and perform.</li>
            <li>• Automation-First — Save time, scale faster.</li>
            <li>• Secure & Compliant — Enterprise-grade protection for customer data.</li>
            <li>• Industry-Ready — Designed for retail and e-commerce challenges.</li>
            <li>• Proven Impact — Real-world performance, measurable outcomes.</li>
          </ul>
        </div>
      </section>

      {/* CTA */}
      <section className="text-primary-foreground py-16 md:py-24 bg-[rgba(223,168,34,1)]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl md:text-5xl font-extrabold text-balance">Future‑Ready Retail Starts Here</h2>
          <p className="mt-4 text-lg">See how ZeaCRM transforms engagement into growth.</p>
          <div className="mt-8 flex gap-4 justify-center">
            <Button asChild size="lg" variant="secondary">
              <Link href="/playbooks/videos">Watch Demo Video</Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="bg-transparent text-primary-foreground border-primary-foreground hover:bg-primary-foreground/10"
            >
              <Link href="/get-started">Start Free Trial</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* FAQs */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h2 className="text-3xl md:text-4xl font-extrabold text-primary text-center">FAQs</h2>
        <div className="mt-8 space-y-6">
          <details className="rounded-lg border border-border p-4 bg-card" open>
            <summary className="cursor-pointer font-semibold">1. How does AI improve engagement?</summary>
            <p className="mt-2 text-muted-foreground">
              ZeaCRM predicts behavior and automates follow-ups to drive conversions.
            </p>
          </details>
          <details className="rounded-lg border border-border p-4 bg-card">
            <summary className="cursor-pointer font-semibold">2. What is AEO and why is it important?</summary>
            <p className="mt-2 text-muted-foreground">
              AEO makes your brand visible in AI tools like ChatGPT and Gemini.
            </p>
          </details>
          <details className="rounded-lg border border-border p-4 bg-card">
            <summary className="cursor-pointer font-semibold">3. Is ZeaCRM GEO-neutral?</summary>
            <p className="mt-2 text-muted-foreground">Yes — it supports multiple languages, currencies, and markets.</p>
          </details>
          <details className="rounded-lg border border-border p-4 bg-card">
            <summary className="cursor-pointer font-semibold">4. Can AI predict future purchases?</summary>
            <p className="mt-2 text-muted-foreground">Yes — ZeaCRM analyzes buying patterns to suggest next orders.</p>
          </details>
          <details className="rounded-lg border border-border p-4 bg-card">
            <summary className="cursor-pointer font-semibold">5. How does automation save time?</summary>
            <p className="mt-2 text-muted-foreground">
              ZeaCRM handles marketing, billing, and customer updates automatically.
            </p>
          </details>
        </div>
      </section>

      <Footer />
    </>
  )
}
