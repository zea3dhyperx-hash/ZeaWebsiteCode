"use client"

export function AniProf() {
  return (
    <div className="w-full h-full min-h-[400px] bg-gradient-to-br from-primary/10 via-accent/10 to-muted rounded-xl flex items-center justify-center p-8">
      <div className="relative w-full h-full">
        {/* Central dashboard mockup */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="bg-card border border-border rounded-lg shadow-2xl p-6 w-full max-w-2xl animate-[fadeIn_1s_ease-in]">
            {/* Header */}
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-red-500"></div>
                <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                <div className="w-3 h-3 rounded-full bg-green-500"></div>
              </div>
              <span className="text-xs text-muted-foreground">ZeaCRM Dashboard</span>
            </div>

            {/* Content bars */}
            <div className="space-y-3">
              <div className="h-4 bg-primary/20 rounded animate-[pulse_2s_ease-in-out_infinite]"></div>
              <div className="h-4 bg-primary/30 rounded w-3/4 animate-[pulse_2s_ease-in-out_infinite_0.2s]"></div>
              <div className="h-4 bg-primary/20 rounded w-1/2 animate-[pulse_2s_ease-in-out_infinite_0.4s]"></div>

              {/* Cards grid */}
              <div className="grid grid-cols-3 gap-3 mt-6">
                <div className="h-20 bg-muted rounded-lg animate-[slideInLeft_0.5s_ease-out]"></div>
                <div className="h-20 bg-muted rounded-lg animate-[slideInLeft_0.5s_ease-out_0.1s]"></div>
                <div className="h-20 bg-muted rounded-lg animate-[slideInLeft_0.5s_ease-out_0.2s]"></div>
              </div>
            </div>
          </div>
        </div>

        {/* Floating elements */}
        <div className="absolute top-4 left-4 w-12 h-12 bg-primary/20 rounded-full animate-[float_3s_ease-in-out_infinite]"></div>
        <div className="absolute bottom-4 right-4 w-16 h-16 bg-accent/20 rounded-full animate-[float_4s_ease-in-out_infinite]"></div>
        <div className="absolute top-1/2 right-8 w-8 h-8 bg-muted/40 rounded-full animate-[float_2.5s_ease-in-out_infinite]"></div>
      </div>
    </div>
  )
}
